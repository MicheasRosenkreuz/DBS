<div style="margin-top: 5%;">
    <form action="pacienti?sel=add_pacient" method="POST">
		<div class="form-group mb-2">
            <textarea class="form-control" name="rc" placeholder="Rodné číslo" required></textarea>	
		</div>
		<select class="form-control" name="superpojistenec_rc" style="margin-top: 1.4%">
				<option value="" selected></option> 
			<?php
				if (isset($superpojistenci)){
					foreach ($superpojistenci as $row) {?>
					<option value="<?= $row->pacient_rc ?>"><?php echo $row->pacient_rc ?></option>
				<?php }
				}?>
		</select>
		<select class="form-control" name="doktor" style="margin-top: 1.4%">
			<?php
				if (isset($doktori)){
					foreach ($doktori as $row) {?>
					<option value="<?= $row->lekar_id ?>"><?php echo $row->jmeno.' '.$row->prijmeni ?></option>
				<?php }
				}?>
		</select>
		<select class="form-control" name="kod_poji" style="margin-top: 1.4%">
			<?php
				if (isset($pojistovny)){
					foreach ($pojistovny as $row) {?>
					<option value="<?= $row->kod_pojistovny ?>"><?php echo $row->nazev ?></option>
				<?php }
				}?>
		</select>
        <div class="form-group" style="margin-top: 1.5%">
            <textarea class="form-control" name="jmeno" placeholder="Jméno" required></textarea>	
		</div>
		<div class="form-group">
            <textarea class="form-control" name="prijmeni" placeholder="Přijmení" required></textarea>	
		</div>
		<div class="form-group">
            <textarea class="form-control" name="adresa" placeholder="Adresa" required></textarea>	
		</div>
		<div class="form-group">
            <textarea class="form-control" name="telefon" placeholder="Telefon" required></textarea>	
		</div>
		<div class="form-group">
            <textarea class="form-control" name="email" placeholder="Email"></textarea>	
		</div>
        <button type="submit" class="btn btn-default" style="margin-bottom: 0.5%">Pridej</button>
    </form>
</div>