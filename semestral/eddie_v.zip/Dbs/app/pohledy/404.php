<?php if(!defined('BASE_DIR')) die('no direct script access');?>

<div class="jumbotron">
  <h1><span class="glyphicon glyphicon-alert" aria-hidden="true"></span>  404 - not found</h1>
  <p>Taková stránka neexistuje...</p>
  <p>Chybové stránky nemusí vypadat ošklivě. Naopak je můžete využít k upoutání pozornosti, nebo alespoň k pobavení návštěvníků.</p>
  <p><a class="btn btn-primary btn-lg" href="http://www.smashingmagazine.com/2009/01/29/404-error-pages-one-more-time/" role="button">
    <span class="glyphicon glyphicon-question-sign" aria-hidden="true"></span> Chci si o tom přečíst víc
    </a>
</p>
</div>

