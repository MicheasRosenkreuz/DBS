<div class="container-fluid">
    <div class="row">
        <h1>Vitej</h1>
    </div>
</div>
<div class="container-fluid">
    <div class="row">
        <p class="text">Pro prochazeni aplikace <a href="user">prihlas</a>.</p>
        <p class="text">Testovani:</br> ID: 1 Heslo: admin</p>
    </div>
</div>
