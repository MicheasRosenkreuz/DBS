<?php if(!defined('BASE_DIR')) die('no direct script access');?>

<div class="jumbotron">
    <h1><span class="glyphicon glyphicon-alert" aria-hidden="true"></span>  500 - server error</h1>
    <p>Chyba aplikace</p>
    <p>Jejda, něco se zvrtlo....</p>
    <p>Samozřejmě, lepší je zobrazit něco <a href="http://www.mfvisuals.com/error500.html">hezčího a legračního</a>.</p>

</div>

