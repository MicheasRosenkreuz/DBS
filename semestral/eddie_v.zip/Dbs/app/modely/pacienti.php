<?php

namespace app\modely;

class Pacienti {

    private $db;

    function __construct($db) {
        $this->db = $db;
    }

    /**
     * @return array s indexy:  {rc, pacient, adresa, telefon, email, lekar, pojistovna, superpojistenec}
     */
    public function selectTablePacient() {
        $sql = "SELECT p.pacient_rc as rc, CONCAT(p.jmeno, ' ', p.prijmeni) as pacient,
	p.adresa as adresa, p.telefon as telefon, p.email as email,
	CONCAT(lekar.jmeno, ' ',  lekar.prijmeni) as lekar, pojistovna.nazev as pojistovna,
	CONCAT(s.jmeno, ' ', s.prijmeni) as superpojistenec
	FROM pacient p join pojistovna on p.kod_pojistovny=pojistovna.kod_pojistovny
	left join pacient s on p.superpojistenec_rc=s.pacient_rc
	join lekar on p.lekar_id=lekar.lekar_id";
        $result = $this->db->query($sql);
        return $result->fetchAll();
    }
    public function getAll() {
        $sql = "SELECT * FROM pacient";
        $result = $this->db->query($sql);
        return $result->fetchAll();
    }
	public function getAllById($id) {
		$params = array(':Lekar_id' => $id);
		$sql = "SELECT pacient_rc as pacient_rc, jmeno as pacient_jm, prijmeni as pacient_pr, adresa as pacient_adr, telefon as pacient_tel, email as pacient_email
FROM pacient WHERE pacient_rc in(select distinct p.pacient_rc from pacient p join zaznam z on p.pacient_rc=z.pacient_rc WHERE :Lekar_id = z.lekar_id);";
		$query = $this->db->prepare($sql);
		$query->execute($params);
		return $query->fetchAll();
	}
	public function getDetailOfPacient($id) {
		$params = array(':pacient_rc' => $id);
		$sql = "SELECT diagnoza, p.jmeno as pacient_jm, p.prijmeni as pacient_pr, p.pacient_rc as pacient_rc FROM zaznam, pacient p, lekar l
				WHERE zaznam.pacient_rc = :pacient_rc and p.pacient_rc = :pacient_rc and l.lekar_id = zaznam.lekar_id";
		$query = $this->db->prepare($sql);
		$query->execute($params);
		return $query->fetchAll();
	}
	public function getLeky(){
		$sql = "SELECT * FROM leky";
		$query = $this->db->query($sql);
		return $query->fetchAll();
	}
	public function getDoctors(){
		$sql = "SELECT * FROM lekar";
		$query = $this->db->query($sql);
		return $query->fetchAll();
	}			
	public function getIdLekuByName($name){
		$params = array(':jmeno' => $name);
		$sql = "SELECT lek_id FROM leky WHERE jmeno = :jmeno";
		$query = $this->db->prepare($sql);
		$query->execute($params);
		return $query->fetch();
	}
	public function insertDiagnoza($pacient_rc, $lekar_id, $diagnoza) {
        $params = array(':pacient_rc' => $pacient_rc, ':lekar_id' => $lekar_id, ':diagnoza' => $diagnoza);
        $sql = "INSERT INTO zaznam (pacient_rc, lekar_id, recept_id, diagnoza, datum)"
                . "VALUES (:pacient_rc, :lekar_id, NULL, :diagnoza, now())";
        $query = $this->db->prepare($sql);
        $query->execute($params);
    }
	public function insertDiagnozaa($pacient_rc, $lekar_id, $recept_id, $diagnoza) {
        $params = array(':pacient_rc' => $pacient_rc, ':lekar_id' => $lekar_id, ':diagnoza' => $diagnoza, ':recept_id' => $recept_id);
        $sql = "INSERT INTO zaznam (pacient_rc, lekar_id, recept_id, diagnoza, datum)"
                . "VALUES (:pacient_rc, :lekar_id, :recept_id, :diagnoza, now())";
        $query = $this->db->prepare($sql);
        $query->execute($params);
    }
	public function getMaxId() {
		$sql = "SELECT MAX(recept_id) as recept_id FROM recept";
		$query = $this->db->query($sql);
		return $query->fetch();
	}
	public function insertRecept($recept_id, $lekar_id, $pacient_rc, $davkovani, $lek_id){
		$params = array(':recept_id' => $recept_id, ':lekar_id' => $lekar_id, ':pacient_rc' => $pacient_rc);
		$paramss = array(':recept_id' => $recept_id, ':davkovani' => $davkovani, ':lek_id' => $lek_id);
        $sql = "INSERT INTO recept (recept_id, pacient_rc, lekar_id, datum_vydani)"
                . "VALUES (:recept_id, :pacient_rc, :lekar_id, now())";
				
		$sqll = "INSERT INTO recept_leky (recept_id, lek_id, davkovani) VALUES (:recept_id, :lek_id, :davkovani)";
        $query = $this->db->prepare($sql);
        $query->execute($params);
		$query = $this->db->prepare($sqll);
		$query->execute($paramss);
	}
	public function getPojistovny(){
		$sql = "SELECT * FROM pojistovna";
		$query = $this->db->query($sql);
		return $query->fetchAll();
	}
	public function insertPacient($rc, $super, $lekar, $poji, $jmeno, $prijmeni, $adresa, $telefon, $email) {
		$params = array(':rc' => $rc, ':super' => $super, ':lekar' => $lekar, ':poji' => $poji, ':jmeno' => $jmeno, ':prijmeni' => $prijmeni, ':adresa' => $adresa, ':telefon' => $telefon, ':email' => $email);
		
		if(sizeof($super) == 0){
			if(sizeof($email) == 0) {
				$insert = " VALUES (:rc, NULL, :lekar, :poji, :jmeno, :prijmeni, :adresa, :telefon, NULL)";
			}else{
				$insert = " VALUES (:rc, NULL, :lekar, :poji, :jmeno, :prijmeni, :adresa, :telefon, :email)";
			}
		}else{
			if(sizeof($email) == 0) {
				$insert = " VALUES (:rc, :super, :lekar, :poji, :jmeno, :prijmeni, :adresa, :telefon, NULL)";
			}else{
				$insert = " VALUES (:rc, :super, :lekar, :poji, :jmeno, :prijmeni, :adresa, :telefon, :email)";
			}
		}
		
		$sql = "INSERT INTO pacient (pacient_rc, superpojistenec_rc, lekar_id, kod_pojistovny, jmeno, prijmeni, adresa, telefon, email)".$insert;
		$query = $this->db->prepare($sql);
		$query->execute($params);
	}
}
