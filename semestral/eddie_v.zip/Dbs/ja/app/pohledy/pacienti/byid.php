<div class="container-fluid content-margin">
    <table class="ukoly table table-hover" data-type="objects">
        <thead>
            <tr>
                <th width="15%">RC pacienta</th>
                <th width="25%">Cele jmeno</th>
                <th width="20%">Adresa</th>
                <th width="20%">Telefon</th>
                <th width="20%">Email</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if(isset($this->_data['pacienti'])) {
                $sal = $this->_data['pacienti'];
                for ($i = 0; $i < sizeof($sal); $i++) {
                    $id = (int) ($sal[$i]->pacient_rc);
                    $id = intval($id);
                    ?>
                    <tr class = "cursor-pointer">				
                        <td><a href="?id=<?= $id ?>" style="display: block"><?= $sal[$i]->pacient_rc ?></a></td>
                        <td><a href="?id=<?= $id ?>" style="display: block"><?= $sal[$i]->pacient_jm.' '.$sal[$i]->pacient_pr ?></a></td>
                        <td><a href="?id=<?= $id ?>" style="display: block"><?= $sal[$i]->pacient_adr?></a></td>
                        <td><a href="?id=<?= $id ?>" style="display: block"><?= $sal[$i]->pacient_tel ?></a></td>
                        <td><a href="?id=<?= $id ?>" style="display: block"><?= $sal[$i]->pacient_email ?></a></td>
                    </tr>

                <?php }
            } ?>


        </tbody>
    </table>
    <div data-type="json">
    </div>
</div>
