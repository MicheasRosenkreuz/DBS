<div class="container-fluid content-margin">
    <table class="ukoly table table-hover" data-type="objects">
        <thead>
            <tr>
                <th width="10%">RC pacienta</th>
                <th width="15%">Cele jmeno</th>
                <th width="10%">Adresa</th>
                <th width="10%">Telefon</th>
                <th width="10%">Email</th>
				<th width="10%">Praktický lékař</th>
				<th width="10%">Superpojištěnec_RC</th>
				<th width="10%">Kód_pojištovna</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if(isset($this->_data['pacienti'])) {
                $sal = $this->_data['pacienti'];
                for ($i = 0; $i < sizeof($sal); $i++) {
                    $id = (int) ($sal[$i]->pacient_rc);
                    ?>
                    <tr class = "cursor-pointer">				
                        <td><a href="?id=<?= $id ?>" style="display: block"><?= $sal[$i]->rc ?></a></td>
                        <td><a href="?id=<?= $id ?>" style="display: block"><?= $sal[$i]->jmeno.' '.$sal[$i]->prijmeni ?></a></td>
                        <td><a href="?id=<?= $id ?>" style="display: block"><?= $sal[$i]->adresa?></a></td>
                        <td><a href="?id=<?= $id ?>" style="display: block"><?= $sal[$i]->telefon ?></a></td>
                        <td><a href="?id=<?= $id ?>" style="display: block"><?= $sal[$i]->email ?></a></td>
                    </tr>

                <?php }
            } ?>


        </tbody>
    </table>
    <div data-type="json">
    </div>
</div>
