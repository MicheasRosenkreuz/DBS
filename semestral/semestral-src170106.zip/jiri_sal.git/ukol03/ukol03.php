<?php
 
$data = "The PHP development team announces the immediate availability of PHP 5.6.30 version. This is a security release. Several security bugs were fixed in this release. All PHP 5.6 users are encouraged to upgrade to this version. According to our release calendar, this PHP 5.6 version is the last planned release that contains regular bugfixes. All the consequent releases will contain only security-relevant fixes, for the term of two years. PHP 5.6 users that need further bugfixes are encouraged to upgrade to PHP 7. For source downloads of PHP 5.6.30 please visit our downloads page, Windows source and binaries can be found on windows.php.net/download/. The list of changes is recorded in the ChangeLog.";
$ple = explode(" ", $data);
 
//oddeleni stringu nesplnujici podminky
for($i = 0 ; $i < sizeof($ple) ; $i++){
    if(strlen($ple[$i])>=6){
        if(strlen(count_chars($ple[$i],3))<=5){
        }else{
            $ple[$i] = "";
        }
    }else{
        $ple[$i] = "";
    }
}
 
//porovnavani stirngu mezi sebou
for($i = 0 ; $i < sizeof($ple) ; $i++){
    if(strlen($ple[$i])>1){
        for($j = $i + 1 ; $j < sizeof($ple) ; $j++){
            if(strlen($ple[$j])>1){
 
                if(strcmp($ple[$i],$ple[$j]) == 0){
                    $ple[$i] = "";
                }
            }
        }
    }
}
 
//vypis slov, která jsou výsledkem
for($i = 0 ; $i < sizeof($ple) ; $i++){
    if(strlen($ple[$i])>1){        
        echo($ple[$i]);
        echo("<br \>");
    }
}
?>