<?php

/*
 * Model pro clanky
 */

class Clanky {

    /**
     * @var PDO $db
     */
    private $db;

    /**
     * model potrebuje spojeni k databazi
     * @param object $db A PDO database connection
     */
    function __construct($db) {
        $this->db = $db;
    }

    /**
     * vsechny clanky z databaze
     * nepouzivame parametr => neni potreba pouzit prepared statements
     * @return array of objects 
     */
    public function getAll() {
        $sql = "SELECT * FROM clanky";
        $result = $this->db->query($sql);
        return $result->fetchAll();
    }

    /**
     * @TODO  / vytvořte metodu pro uložení článků do databáze
     * @param array $articles - array of articles
     * @return boolean $result - výsledek ukládání - true nebo false
     */
    public function saveArticles($articles) {
        for ($i = 0; $i < sizeof($articles); $i++) {
            $url = $articles[$i][2];
            $title = $articles[$i][1];
            $author = $articles[$i][0];
            $abstract = $articles[$i][3];
            try {
                $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                $query = "INSERT INTO clanky (url,title,author,abstract) VALUES ('$url','$title','$author','$abstract')";
                $this->db->exec($query);
            } catch (PDOException $e) {
                return $sql . "<br>" . $e->getMessage();
            }
        }
        return true;
    }

    public function delka() {
        $sql = "SELECT * FROM clanky";
        $result = $this->db->query($sql);
        return $result->rowCount();
    }

    /**
     * @TODO  / vytvořte metodu pro uložení článků do databáze
     * @param string $json_string - json data
     * @return array $articles - array of articles
     * ze vstupního json souboru stačí zachovat url, titulek, abstrakt a jméno autora
     */
    public function getArticlesFromJson($json_string) {
        $json = json_decode($json_string);
        $pocet = 0;
        $array = array();
        $pole = array();
        foreach ($json as $tmp) {
            if (!is_null($tmp->byline)) {
                $array[$pocet] = $tmp->byline;
                $pocet++;
            }if (!is_null($tmp->title)) {
                $array[$pocet] = $tmp->title;
                $pocet++;
            }if (!is_null($tmp->url)) {
                $array[$pocet] = $tmp->url;
                $pocet++;
            }if (!is_null($tmp->abstract)) {
                $array[$pocet] = $tmp->abstract;
                $pocet++;
            }
            if ($pocet == 4) {
                $pole[] = array($array[0], $array[1], $array[2], $array[3]);
                $pocet = 0;
            }
        }
        return $pole;
    }

    /**
     * @TODO  / vytvořte metodu pro uložení článků do databáze
     * @param string $url - url of web data
     * @return string $json_string - json data
     * 
     */
    public function getJsonFromURL($url) {
        ini_set("allow_url_fopen", 1);
        $json = file_get_contents($url);
        return $json;
    }

}
