<?php

include 'clanky.php';

$url = 'http://www.nti.tul.cz/~vrany/weap/articles.json';

//@TODO - vytvořit instanci PDO spojení 
$db = @new PDO("mysql:host=localhost;dbname=clanky", "root", "root");
if ($db->errorCode()){
    throw new Exception($db->errorCode());
}

//@TODO  - implementujte metody ve třídě články
$clanky = new Clanky($db);
$jsonString = $clanky->getJsonFromURL($url);
$articles = $clanky->getArticlesFromJson($jsonString);
$result = $clanky->saveArticles($articles);

if ($result === true) {
    //@TODO - vypsat počet článků v databázi
    $result = $clanky->delka();
    echo $result;
} else {
    echo $result;
    //@TODO - vypsat chybové hlášení
}