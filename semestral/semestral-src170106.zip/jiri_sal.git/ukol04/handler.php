<?php
if (filter_var($_POST["email"], FILTER_VALIDATE_EMAIL)){
    print("email je validní");
} else print("email není validní");

        ?>
