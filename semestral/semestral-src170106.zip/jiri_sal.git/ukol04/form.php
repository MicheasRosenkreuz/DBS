<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form method="POST" action="handler.php" >
            <p>email - :
        <input type="text" name="email" size="40">
            <p>jmeno - :
        <input type="text" name="jmeno" size="30"> 
            <p>prijmeni - :
        <input type="text" name="prijmeni" size="30">
        <br>
        <input type="submit" value="Odeslat"></p>
        </form>
        <?php
        
        
        ?>
    </body>
</html>
