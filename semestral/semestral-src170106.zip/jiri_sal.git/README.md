http://salweap.g6.cz/
http://salweap.g6.cz/tasks?sel=json
Nick:admin Pass:admin