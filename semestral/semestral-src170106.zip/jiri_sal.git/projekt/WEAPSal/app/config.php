<?php
//konstanty
define('BASE_DIR', '/ salweap.g6.cz / web /');
define('STATIC_DIR', BASE_DIR . '/static/');
define('DEBUG', true);

//databaze
define('DB_TYPE', 'mysql');
define('DB_HOST', 'localhost');
define('DB_NAME', 'salweap');
define('DB_USER', 'salweapg6cz');
define('DB_PASS', 'killer6');