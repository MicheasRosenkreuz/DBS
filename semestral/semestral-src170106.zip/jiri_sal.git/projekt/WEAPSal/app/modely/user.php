<?php

namespace app\modely;


class user {

    private $db;

    function __construct($db) {
        $this->db = $db;
    }

    public function getAll() {
        $sql = "SELECT User_id, User_name, User_pass FROM user";
        $result = $this->db->query($sql);
        return $result->fetchAll();
    }

    public function getById($id) {
        $params = array(':User_id' => $id);
        $sql = "SELECT User_id, User_name, User_pass FROM user WHERE User_id = :User_id";
        $query = $this->db->prepare($sql);
        $query->execute($params);
        return $query->fetch();
    }

    public function getByName($name) {
        $params = array(':User_name' => $name);
        $sql = "SELECT User_id, User_name, User_pass FROM user WHERE User_name = :User_name";
        $query = $this->db->prepare($sql);
        $query->execute($params);
        return $query->fetch();
    }

    public function getIdByName($name) {
        $params = array(':User_name' => $name);
        $sql = "SELECT User_id FROM user WHERE User_name = :User_name";
        $query = $this->db->prepare($sql);
        $query->execute($params);
        $id = $query->fetch();
        if (is_object($id)) {
            $id = $id->User_id;
        } else {
            $id = 0;
        }
        return $id;
    }
    public function getPassByName($name){
        $params = array(':User_name' => $name);
        $sql = "SELECT User_pass FROM user WHERE User_name = :User_name";
        $query = $this->db->prepare($sql);
        $query->execute($params);
        $pass = $query->fetch();
        if (is_object($pass)) {
            $pass = $pass->User_pass;
        } else {
            $pass = 0;
        }
        return $pass;
    }
        public function getNameById($id) {
        $params = array(':User_id' => $id);
        $sql = "SELECT  User_name FROM user WHERE User_id = :User_id";
        $query = $this->db->prepare($sql);
        $query->execute($params);
        return $query->fetch();
    }

}
