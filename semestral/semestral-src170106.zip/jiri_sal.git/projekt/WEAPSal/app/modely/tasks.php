<?php

namespace app\modely;

class tasks {

    private $db;

    function __construct($db) {
        $this->db = $db;
    }

    public function getAll() {
        $sql = "SELECT * FROM task ORDER BY Task_id";
        $result = $this->db->query($sql);
        return $result->fetchAll();
    }

    public function getByUserId($id) {
        $params = array(':User_id' => $id);
        $sql = "SELECT Task_id, Task_value, Task_status FROM task WHERE Task_user_id = :User_id";
        $query = $this->db->prepare($sql);
        $query->execute($params);
        return $query->fetch();
    }

    public function insertTask($id) {
        $params = array(':Value' => $_POST['value'], ':User_id' => $id);
        $sql = "INSERT INTO task (Task_value, Task_user_id)"
                . "VALUES (:Value, :User_id)";
        $query = $this->db->prepare($sql);
        $query->execute($params);
    }

    public function getById($id) {
        $params = array(':Task_id' => $id);
        $sql = "SELECT * FROM task WHERE Task_id = :Task_id";
        $query = $this->db->prepare($sql);
        $query->execute($params);
        return $query->fetch();
    }

    public function updateStatusByTaskId($id) {
        $params = array(':Task_id' => $id, ':Task_status' => 1);
        $sql = "UPDATE task SET Task_status = :Task_status WHERE Task_id = :Task_id";
        $query = $this->db->prepare($sql);        
        $query->execute($params);
    }

    public function updateValueByTaskId($id) {
        $params = array(':Value' => $_POST['newvalue'], ':Task_id' => $id);
        $sql = "UPDATE task SET Task_value = :Value WHERE Task_id = :Task_id";
        $query = $this->db->prepare($sql);       
        $query->execute($params); 
   }
   
   public function deleteTaskByTaskId($id){
       $params = array(':Task_id' => $id);
       $sql = "DELETE FROM task WHERE Task_id = :Task_id";
       $query = $this->db->prepare($sql);
       $query->execute($params);
   }

}
