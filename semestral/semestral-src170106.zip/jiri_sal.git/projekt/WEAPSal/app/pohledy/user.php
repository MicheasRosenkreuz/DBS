<div class="container-fluid">
    <div class="row">
        <h1>Vitej</h1>
    </div>
</div>
<div class="container-fluid">
    <div class="row">
        <p class="text">Jsi přihlášen jako: <?php echo $_SESSION['jmeno']?><p>
    </div>
</div>
