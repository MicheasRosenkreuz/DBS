<?php
    session_unset();
?>
<p class="text"><H4> Byl jsi odhlášen. </h4></p>
