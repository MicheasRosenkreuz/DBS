<div class="container-fluid">
    <div class="row">
        <h1>Vitej</h1>
    </div>
</div>
<div class="container-fluid">
    <div class="row">
        <p class="text">Pro zobrazeni ukolu se <a href="user">prihlas</a>.</p>
        <p class="text">Administrace:</br> Jmeno: admin Heslo: admin</p>
    </div>
</div>
