<div style="margin-top: 10%;">
    <form action="tasks?sel=changevalue" method="POST">
        <div class="form-group">
            <textarea class="form-control" name="newvalue" placeholder="Text" required></textarea>
        </div>
        <button type="submit" class="btn btn-default">Změň</button>
    </form>
</div>