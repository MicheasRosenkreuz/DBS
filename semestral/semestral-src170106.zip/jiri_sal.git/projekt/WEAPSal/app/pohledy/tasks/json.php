<div class="container-fluid">
    <table class="ukoly table table-hover table-bordered" >

    </table>

    <div data-type="json">
    </div>
</div>

<?php
echo json_encode($this->_data);