<div class="container-fluid content-margin">
    <table class="ukoly table table-hover" data-type="objects">
        <thead>
            <tr>
                <th width="10%">ID</th>
                <th width="80%">Value</th>
                <th width="10">Status</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (isset($this->_data['ukoly'])) {
                $sal = $this->_data['ukoly'];
                for ($i = 0; $i < sizeof($sal); $i++) {
                    
                    if ($sal[$i]->Task_status == '0') {
                        $id = (int) ($sal[$i]->Task_id);
                        $id = intval($id);
                        ?>
                        <tr class = "cursor-pointer">
                            <td><a href="?id=<?= $id ?>" style="display: block"><?= $sal[$i]->Task_id ?></a></td>
                            <td><a href="?id=<?= $id ?>" style="display: block"><?= $sal[$i]->Task_value ?></a></td>
                            <td><a href="?id=<?= $id ?>" style="display: block"><?= $sal[$i]->Task_status == 0 ? "NE" : "ANO" ?></a></td>
                        </tr>

                    <?php
                    }
                }
            }
            ?>


        </tbody>
    </table>
    <div data-type="json">
    </div>
</div>
