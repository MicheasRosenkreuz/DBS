<div class="container-fluid">
    <table class="ukoly table table-hover table-bordered" >
        <tbody>

            <tr>
                <td width="25%">ID: </td><td><?= $this->_data['ukol']->Task_id ?></td>
            </tr>
            <tr>
                <td width="25">Znění úkolu: </td><td><?= $this->_data['ukol']->Task_value ?></td>
            </tr>

            <tr>
                <td width="25">Zadavatel: </td><td><?= $this->_data['user'] ?></td>
            </tr>
        </tbody>

    </table>
    <table class="container-fluid">
        <?php if ($this->_data['ukol']->Task_status == 0) { ?><td width="50%"><a href="?sel=changestatus"><button class="btn btn-lg">Dokončit úkol</button></a></td><?php } ?>
        <td><a href="?changevalue=yes"><button class="btn btn-lg">Změnit znění</button></a></td>
        <td><a href="?sel=delete"><button class="btn btn-lg" style="margin-left: 10%;">Odebrat tento ukol</button></a></td>
        
    </table>
    <div data-type="json">
    </div>
</div>
